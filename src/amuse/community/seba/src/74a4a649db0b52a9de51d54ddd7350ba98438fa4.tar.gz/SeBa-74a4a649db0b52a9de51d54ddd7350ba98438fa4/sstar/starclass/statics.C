/* Implementation of all statics, when combining this with Starlab this file probably needs to be removed. */

#include "star.h"

seba_counters* star::sc = new seba_counters;
